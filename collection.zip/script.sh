python > output.txt  <<EOF
execfile('/home/jchohan/index.py')
a=index('/home/jchohan/collection/')
a.buildIndex()
a.print_dict()
a.and_query(['edward','years','the' ])
a.and_query(['their','indian'])
a.and_query(['everywhere','minnesota','but'])
a.print_doc_list()
EOF

